<?php
/*
 * Template Name: Default page
 */

get_header(); ?>

<style>
body, #content, #content2 {
  background-color: <?php echo of_get_option('about_colorpicker', 'no entry'); ?>;
}

.diselect_navi, #headlines-resume, #headlines-contact {
  color: <?php echo of_get_option('about_colorpicker', 'no entry'); ?> !important;
}

a:hover {
  color: <?php echo of_get_option('main_colorpicker', 'no entry'); ?>;
}

#navigation-single-post, #submit, .navigation_color, .nav-category-item, .skills-line, .icons, #submit_form, #submit, .navigation-page a, #content4 {
  background-color: <?php echo of_get_option('main_colorpicker', 'no entry'); ?>; 
}

.ch-info {
    background-color: <?php echo of_get_option('main_colorpicker', 'no entry'); ?> !important;
}

#about-me-box, #resume-box, #gallery {
  border-left: 5px solid <?php echo of_get_option('main_colorpicker', 'no entry'); ?>;
}

.company, .success_message, .filter:hover, .filter.active, #submit:hover, #submit_form:hover, .navigation-page a:hover, .email-erorr, .name-erorr, .message-erorr, .no-touch .hi-icon-effect-1a .hi-icon:hover, #alt_socila-complet i:hover, .fa-calendar, .fa-tag, .fa-folder-open, .fa-comments, .commentmetadata:before, .fn:before, .comment-awaiting-moderation:before  {
  color: <?php echo of_get_option('main_colorpicker', 'no entry'); ?>;
}  

.input, input, textarea {
  border-bottom: 3px solid <?php echo of_get_option('main_colorpicker', 'no entry'); ?>;
}

.comment-body {
  border-left: 3px solid <?php echo of_get_option('main_colorpicker', 'no entry'); ?>;
}

#navigation-name, #headlines-about, #headlines-portfolio, .selection-resume .fa, #download a:hover, #socila-complet i:hover, .post-title, .title {
  color: <?php echo of_get_option('resume_colorpicker', 'no entry'); ?>;
}

#item_1:hover, #item_2:hover, #item_3:hover, #item_4:hover, #item_6:hover, .navigation-wrapper a:hover, .select_navi {
  color: <?php echo of_get_option('resume_colorpicker', 'no entry'); ?> !important;
} 

#overlay-black, #content1, #content3, #alt_content4 {
  background-color: <?php echo of_get_option('resume_colorpicker', 'no entry'); ?>;
}
</style>

<div id="navigation-single-post">
    <div class="navigation-wrapper">
    <span id="navigation-name"><a href="<?php echo site_url(); ?>"><?php echo of_get_option('user_name', 'no entry'); ?></a></span>  
    
    <span id="item_1"><a href="<?php echo site_url(); ?>">HOME</a></span>
    
    </div>
</div>

<div id="main-content" class="main-content">
		<div id="content-post" class="site-content" role="main">

    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php the_content(); ?>
                    <?php endwhile; endif; ?>
    
    </div>
</div>
<div id="alt_content4">
  <div id="selection-download">
      <div id="alt_socila-complet"> 
        <?php if ( 1 == of_get_option('twitter_checkbox_footer') ) { ?>   
        <a href="<?php echo of_get_option('twitter_url', 'no entry'); ?>"><i class="fa fa-twitter"></i></a>
        <?php } else { ?>
        <?php } ?>
        <?php if ( 1 == of_get_option('facebook_checkbox_footer') ) { ?>
        <a href="<?php echo of_get_option('facebook_url', 'no entry'); ?>"><i class="fa fa-facebook"></i></a>
        <?php } else { ?>
        <?php } ?>
        <?php if ( 1 == of_get_option('dribbble_checkbox_footer') ) { ?> 
        <a href="<?php echo of_get_option('dribbble_url', 'no entry'); ?>"><i class="fa fa-dribbble"></i></a>
        <?php } else { ?>
        <?php } ?>
        <?php if ( 1 == of_get_option('pinterest_checkbox_footer') ) { ?> 
        <a href="<?php echo of_get_option('pinterest_url', 'no entry'); ?>"><i class="fa fa-pinterest"></i></a>
        <?php } else { ?>
        <?php } ?>
        <?php if ( 1 == of_get_option('google_checkbox_footer') ) { ?> 
        <a href="<?php echo of_get_option('google_url', 'no entry'); ?>"><i class="fa fa-google-plus"></i></a> 
        <?php } else { ?>
        <?php } ?>
        <?php if ( 1 == of_get_option('instagram_checkbox_footer') ) { ?> 
        <a href="<?php echo of_get_option('instagram_url', 'no entry'); ?>"><i class="fa fa-instagram"></i></a>
        <?php } else { ?>
        <?php } ?>
        <?php if ( 1 == of_get_option('linkedin_checkbox_footer') ) { ?>   
        <a href="<?php echo of_get_option('linkedin_url', 'no entry'); ?>"><i class="fa fa-linkedin"></i></a>
        <?php } else { ?>
        <?php } ?>
        <?php if ( 1 == of_get_option('behance_checkbox_footer') ) { ?>   
        <a href="<?php echo of_get_option('behance_url', 'no entry'); ?>"><i class="fa fa-behance"></i></a>
        <?php } else { ?>
        <?php } ?>
        <?php if ( 1 == of_get_option('tumblr_checkbox_footer') ) { ?>   
        <a href="<?php echo of_get_option('tumblr_url', 'no entry'); ?>"><i class="fa fa-tumblr"></i></a>
        <?php } else { ?>
        <?php } ?>
        <?php if ( 1 == of_get_option('deviantart_checkbox_footer') ) { ?>   
        <a href="<?php echo of_get_option('deviantart_url', 'no entry'); ?>"><i class="fa fa-deviantart"></i></a>
        <?php } else { ?>
        <?php } ?>
    </div>
  </div>
</div>
<?php wp_footer(); ?>
</body>
</html>
